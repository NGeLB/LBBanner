// 开发者: NGeLB
// QQ交流群: 572296164
// GitHub 代码地址:https://github.com/NGeLB/LBBanner




#import <UIKit/UIKit.h>

const CGFloat LBBannerTitleHeight = 25.0;
