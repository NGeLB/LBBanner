//
//  LBBannerConst.m
//  TurnPageTest
//
//  Created by 你个LB on 16/9/21.
//  Copyright © 2016年 你个LB. All rights reserved.
//

#import <UIKit/UIKit.h>

const CGFloat LBBannerTitleHeight = 25.0;
