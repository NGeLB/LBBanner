//
//  UIView+ViewController.h
//  WXMovie
//
//  Created by zsm on 14-4-21.
//  Copyright (c) 2014年 zsm. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (ViewController)

- (UIViewController *)viewController;
@end
